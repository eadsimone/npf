<?php // This runs when outside the wp-admin.


// ********** ACTIONS (public) **********



// ********** AJAX (public) **********



// ********** FILTERS (public) **********



// ********** SHORTCODES (public) **********



?>
