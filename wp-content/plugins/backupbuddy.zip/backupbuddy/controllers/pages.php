<?php

// NOTE: DO NOT PUT PAGES HERE FOR NOW -- PUT THEM IN A PAGENAME.PHP FILE IN THE CONTROLLERS/PAGES SUBDIRECTORY.

class pb_backupbuddy_pages extends pb_backupbuddy_pagescore {
	// See note above.
}
?>