<div class="wrap">
<h2>Featured Image In Rss Feed</h2><br/>
<table width="100%">
	<tr>
    	<td valign="top">          