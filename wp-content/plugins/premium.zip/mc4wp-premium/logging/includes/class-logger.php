<?php

/**
 * Class MC4WP_Logger
 *
 * @ignore
 */
class MC4WP_Logger {

	/**
	 * @var string
	 */
	private $table_name = '';

	/**
	 * @var WPDB
	 */
	private $db;

	/**
	 * Constructor
	 *
	 * @param WPDB $wpdb
	 */
	public function __construct( $wpdb = null ) {

		if( null === $wpdb ) {
			global $wpdb;
		}

		$this->db = $wpdb;
		$this->table_name = $wpdb->prefix . 'mc4wp_log';
	}

	/**
	 *
	 */
	public function add_hooks() {
		// add listeners for core logging
		add_action( 'mctb_subscribed', array( $this, 'log_top_bar_request' ), 10, 3 );
		add_action( 'mc4wp_integration_subscribed', array( $this, 'log_integration_request' ), 10, 4 );
		add_action( 'mc4wp_form_subscribed', array( $this, 'log_form_request' ), 10, 3 );
	}

	/**
	 * @param string $list
	 * @param string $email
	 * @param string $merge_vars
	 *
	 * @return int
	 */
	public function log_top_bar_request( $list, $email, $merge_vars ) {
		return $this->add(
			$email,
			$list,
			$merge_vars,
			'mc4wp-top-bar',
			null,
			MC4WP_Request::create_from_globals()->get_referer()
		);
	}

	/**
	 * @param MC4WP_Integration $integration
	 * @param string $email
	 * @param array $merge_vars
	 * @param int $related_object_id
	 *
	 * @return false|int
	 */
	public function log_integration_request( MC4WP_Integration $integration, $email, $merge_vars, $related_object_id = 0 ) {
		return $this->add(
			$email,
			$integration->get_lists(),
			$merge_vars,
			$integration->slug,
			$related_object_id,
			MC4WP_Request::create_from_globals()->get_referer()
		);
	}

	/**
	 * @param MC4WP_Form $form
	 * @param string $email
	 * @param array $merge_vars
	 *
	 * @return false|int
	 */
	public function log_form_request( MC4WP_Form $form, $email, $merge_vars ) {

		// for BC with MailChimp for WordPress < 3.1.6
		if( is_array( $email ) ) {
			$merge_vars = $email;
			$email = $form->data['EMAIL'];
		}
		unset( $merge_vars['EMAIL'] );
		unset( $merge_vars['_MC4WP_LISTS'] );

		return $this->add(
			$email,
			$form->get_lists(),
			$merge_vars,
			'mc4wp-form',
			$form->ID,
			MC4WP_Request::create_from_globals()->get_referer()
		);
	}


	/**
	 * @param string $email Email address to log
	 * @param string|array  $list_ids String or array of list ID's
	 * @param array  $data The data that was sent to MailChimp
	 * @param string $type The type that was used (form, integration slug, ...)
	 * @param int    $related_object_id ID of the related object, if any (form, comment, user, etc..)
	 * @param string $url The URl the request originated from
	 *
	 * @return false|int
	 */
	public function add( $email, $list_ids, $data = array(), $type = 'form', $related_object_id = 0, $url = '' ) {

		// make sure `$list_ids` is a string
		if( is_array( $list_ids ) ) {
			$list_ids = implode( ',', array_map( 'trim', $list_ids ) );
		}

		return $this->db->insert( $this->table_name, array(
				'email'     => $email,
				'list_ids'  => $list_ids,
				'data'      => json_encode( $data ),
				'type'      => $type,
				'related_object_ID' => (int) $related_object_id,
				'url'       => $url,

				// store GMT date
				'datetime'  => current_time( 'mysql', true )
			)
		);
	}

	/**
	 * @param array $args
	 * @return int
	 */
	public function count( $args = array() ) {
		$args['select'] = 'COUNT(*)';
		return $this->find( $args );
	}

	/**
	 * @param array $args
	 * @param string $output_type
	 * @return int|mixed
	 */
	public function find( $args, $output_type = OBJECT ) {

		$args = wp_parse_args( $args, array(
			'select' => '*',
			'offset' => 0,
			'limit' => 1,
			'orderby' => 'id',
			'order' => 'DESC',

			// where params
			'type' => '',
			'email' => '',
			'datetime_after' => '',
			'datetime_before' => '',
			'include_errors' => true
		) );

		$where = array();
		$params = array();

		// build general select from query
		$query = sprintf( "SELECT %s FROM %s", $args['select'], $this->table_name );

		// add email to WHERE clause
		if ( '' !== $args['email'] ) {
			$where[] = 'email LIKE %s';
			$params[] = '%%' . $this->db->esc_like( $args['email'] ). '%%';
		}

		// add type to WHERE clause
		if ( '' !== $args['type'] ) {
			$where[] = 'type = %s';
			$params[] = $args['type'];
		}

		// add datetime to WHERE clause
		if( '' !== $args['datetime_after'] ) {
			$where[] = 'UNIX_TIMESTAMP(datetime) >= %d';
			$datetime_after = is_numeric( $args['datetime_after'] ) ? $args['datetime_after'] : strtotime( $args['datetime_after'] );
			$params[] = $datetime_after;
		}

		if( '' !== $args['datetime_before'] ) {
			$where[] = 'UNIX_TIMESTAMP(datetime) <= %d';
			$datetime_before = is_numeric( $args['datetime_before'] ) ? $args['datetime_before'] : strtotime( $args['datetime_before'] );
			$params[] = $datetime_before;
		}

		// add where parameters
		if ( count( $where ) > 0 ) {
			$query .= ' WHERE '. implode( ' AND ', $where );
		}

		// prepare parameters
		if( ! empty( $params ) ) {
			$query = $this->db->prepare( $query, $params );
		}

		// return result count
		if ( $args['select'] === 'COUNT(*)' ) {
			return (int) $this->db->get_var( $query );
		}

		// return single row
		if( $args['limit'] === 1 ) {
			$query .= ' LIMIT 1';
			return $this->db->get_row( $query );
		}

		// perform rest of query
		$args['limit']  = absint( $args['limit'] );
		$args['offset'] = absint( $args['offset'] );
		$args['orderby'] = preg_replace( "/[^a-zA-Z]/", "", $args['orderby'] );
		$args['order'] = preg_replace( "/[^a-zA-Z]/", "", $args['order'] );

		// add ORDER BY, OFFSET and LIMIT to SQL
		$query .= sprintf( ' ORDER BY %s %s LIMIT %d, %d', $args['orderby'], $args['order'], $args['offset'], $args['limit'] );

		return $this->db->get_results( $query, $output_type );
	}

	/**
	 * @param $ids string|array
	 *
	 * @return mixed
	 */
	public function find_by_id( $ids ) {

		if( is_array( $ids ) ) {
			// create comma-separated string
			$ids = implode( ',', $ids );
		}

		// escape string for usage in IN clause
		$ids = esc_sql( $ids );

		$sql = sprintf( "SELECT * FROM `%s` WHERE ID IN (%s)", $this->table_name, $ids );

		// return single row if only one id is given
		if( substr_count( $ids, ',' ) === 0 ) {
			return $this->db->get_row( $sql );
		}

		return $this->db->get_results( $sql );
	}

	/**
	 * @param $ids Array or string of log ID's to delete
	 *
	 * @return false|int
	 */
	public function delete_by_id( $ids) {

		if( is_array( $ids ) ) {
			// create comma-separated string
			$ids = implode( ',', $ids );
		}

		// escape string for usage in IN clause
		$ids = esc_sql( $ids );

		$sql = sprintf( "DELETE FROM `%s` WHERE ID IN (%s)", $this->table_name, $ids );
		return $this->db->query( $sql );
	}

	/**
	 * Deletes ALL log items. Use with caution.
	 */
	public function truncate() {
		$query =sprintf( "DELETE FROM `%s`", $this->table_name );
		$this->db->query( $query );
	}

}
