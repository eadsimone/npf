<?php

/**
 * Class MC4WP_Logging_Installer
 * @todo
 */
class MC4WP_Logging_Installer {

}