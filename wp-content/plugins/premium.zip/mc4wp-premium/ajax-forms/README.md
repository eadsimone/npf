### MailChimp for WordPress - AJAX Forms

This add-on plugin adds AJAX functionality to MailChimp for WordPress its sign-up forms.